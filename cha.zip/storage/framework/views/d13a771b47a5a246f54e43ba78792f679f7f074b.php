<?php $__env->startSection('main_container'); ?>
    <div class="right_col" role="main">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

        <footer class="imond">
            <div class="pull-right">
              &copy;2017 MTRH LMS by <a href="#">Charity</a>
            </div>
            <div class="clearfix"></div>
        </footer>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('hr.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>