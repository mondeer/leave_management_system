<?php $__env->startSection('content'); ?>
      <div class="row">
          <div class="col-md-12">
              <h1 class="page-head-line">Request For A Conference Room</h1>
          </div>
      </div>

      <div class="col-md-6">
          <div class="panel panel-default">
            <div class="panel-heading">

            </div>
            <div class="panel-body">
             <form>
                <div class="form-group">
                  <label>Employee Name</label>
                  <input type="text" class="form-control" name="emp_name" value="<?php echo e(old('emp_name')); ?>" placeholder="Employee Name" />
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Personal Number</label>
                  <input type="text" class="form-control" name="pf" value="<?php echo e(old('pf')); ?>" placeholder="Personal Number" />
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Department</label>
                  <input type="text" class="form-control" name="department" value="<?php echo e(old('department')); ?>" placeholder="Department" />
                </div>

                <div class="form-group">
                  <label>Conference Room</label>
                  <input type="text" class="form-control" name="conference_room"  placeholder="Personal Number" />
                </div>

                <button type="submit" class="btn btn-default">Submit</button>
              </div>
            </form>
          </div>
          </div>
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>