<?php $__env->startSection('content'); ?>
<h1 class="text-center">Employees On Leave</h1>
  <table class="table table-bordered">
    <thead>
    <tr>
        <th>ID</th>
        <th>Employee Name</th>
        <th>Leave Days</th>
        <th>Edit</th>

    </tr>
    </thead>
    <tbody>

      <?php $__currentLoopData = $onleaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onleave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($onleave->id); ?></td>
          <td><?php echo e($onleave->f_name); ?> <?php echo e($onleave->l_name); ?></td>
          <td><?php echo e($onleave->leave_days); ?></td>
          <td>
            <form action="/admin/recall/<?php echo e($onleave->id); ?>" method="post">
              <input type="hidden" name="_method" value="delete">
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
              <input type="submit" class="btn btn-primary" value="Recall">
            </form>
          </td>

        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('hr.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>