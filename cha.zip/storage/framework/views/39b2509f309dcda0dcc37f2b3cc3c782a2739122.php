<?php $__env->startSection('content'); ?>
<h1 class="text-center">My Applications</h1>
  <table class="table table-bordered">
    <thead>
    <tr>
        <th>ID</th>
        <th>Employee Name</th>
        <th>Leave Days</th>
        <th>Edit</th>

    </tr>
    </thead>
    <tbody>

      <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($leave->id); ?></td>
          <td><?php echo e($leave->f_name); ?> <?php echo e($leave->l_name); ?></td>
          <td><?php echo e($leave->leave_days); ?></td>
          <td>
            <a href="/leaves/edit/<?php echo e($leave->id); ?>">Edit</a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employee.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>