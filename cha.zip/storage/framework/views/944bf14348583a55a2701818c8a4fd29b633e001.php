

<?php $__env->startSection('content'); ?>
  <div class="row">
    <h1>Enter Employee Into the system</h1>
    <hr><hr>

    <form class="form-horizontal" action="/create/employee" method="post">
      <?php echo e(csrf_field()); ?>

      <div class="col-md-8">

        <div class="form-group">
          <label class="col-md-2">First Name</label>
          <div class="">
            <input class="col-md-3" type="text" name="f_name" value="<?php echo e(old('f_name')); ?>">
          </div>
          <label class="col-md-2">Last Name</label>
          <div class="">
            <input class="col-md-3" type="text" name="l_name" value="<?php echo e(old('l_name')); ?>">
          </div>
        </div>

        <div class="form-group">
          <label class="col-md-2">PF Number</label>
          <div class="">
            <input class="col-md-3" type="number" name="pf_number" value="<?php echo e(old('pf_number')); ?>">
          </div>
          <label class="col-md-2">Gender</label>
          <div class="">
            <input class="col-md-3" type="text" name="gender" value="<?php echo e(old('gender')); ?>">
          </div>
        </div>

        <div class="form-group">

          <label class="col-md-3">Date of Appointment</label>
          <div class="">
            <input class="col-md-3" type="text" name="dop" value="<?php echo e(old('dop')); ?>">
          </div>
        </div>

        <div class="form-group">
          <label class="col-md-2">Department</label>
          <div class="">
            <input type="text" name="department" value="<?php echo e(old('department')); ?>">
          </div>
        </div>


        <div class="align-center">
          <input class="btn btn-success col-md-offset-4" type="submit" name="" value="Submit">
        </div>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('hr.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>